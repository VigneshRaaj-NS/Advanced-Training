class NameNotValidException extends Exception
{
     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String validname()
     {
          return ("Name is not Valid. Please Re-enter the Name");
     }
}public class Demo {
    
}
