import java.util.Scanner;

public class TestRectangle {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
		
		Rectangle  obj2 = new Rectangle(1, 1);
		System.out.print("Enter length of rectangle: ");
		float length= sc.nextFloat();
		sc.nextLine();
		obj2.setLength(length);
		System.out.print("Enter breadth of rectangle: ");
		float breadth= sc.nextFloat();
		sc.nextLine();
		obj2.setBreadth(breadth);
		obj2.calculateArea();
		obj2.calculatePerimeter();
		obj2.displayArea();
		obj2.displayPerimeter();
		sc.close();
    }
}
