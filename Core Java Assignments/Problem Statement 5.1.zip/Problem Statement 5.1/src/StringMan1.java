public class StringMan1 {
    public static void main(String args[]) {
        String str= "JAVA is simple";
        System.out.println("The string is "+str);
        System.out.println("The string in uppercase: "+str.toUpperCase()); 
        System.out.println("The string in lowercase: "+str.toLowerCase());
        
        String arr[]=str.split(" ",3); 
        
        for (String string : arr) {
            System.out.print(string.charAt(0)+" "); 
        }
        System.out.println();
        
        
        for(int i=arr.length-1; i>=0; i--) {
            System.out.print(arr[i]+" ");
        }
        System.out.println();
        
        
        for(int i=0; i<arr.length; i++) {
            StringBuilder word= new StringBuilder(arr[i]);
            System.out.print(word.reverse());
            System.out.print(" ");
        }

        System.out.println();
        System.out.println("length is "+str.length());
            
    }
}