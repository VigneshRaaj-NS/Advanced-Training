import java.util.Scanner;

public class BankAccount {
	long accNo;
	float balance;
	String custName, accType;


	public BankAccount() {

	}

	public BankAccount(long accNo, float balance, String custName, String accType) {
		super();
		this.accNo = accNo;
		this.balance = balance;
		this.custName = custName;
		this.accType = accType+" Account";
	}

	public void deposit(float amt) throws Exception {
		if(amt<0){
			try {
				throw new NumberFormatException();
			}

			catch(NumberFormatException nw){
				System.out.println("Can not deposit negative amount");
			}
			return;
		}
		else {
			balance = getBalance()+amt;
			System.out.println(amt+" deposited successfully");
		}
		display();
	}

	public void withdraw(float amt) throws Exception{
		if(accType.equalsIgnoreCase("Savings Account")) {
			if((getBalance()-amt)<1000 || (amt>getBalance())) {
				try{
					throw new Exception();
				}
				catch(Exception e){
					System.out.println("Insufficient funds, Transaction cancelled!!");
				}
				return;
			}

			else
			{
				balance= getBalance()-amt;
			}
			display();

		}

		if(accType.equalsIgnoreCase("Current Account")) {
			if(getBalance()-amt<5000 || (amt>getBalance())) {
				try{
					throw new Exception();
				}
				catch(Exception e){
					System.out.println("Insufficient funds, Transaction cancelled!!");
				}
				return;
			}

			else
			{
				balance= getBalance()-amt;
			}
			display();
		}
	}

	public float getBalance() throws Exception{
		
		if( (accType.equalsIgnoreCase("Savings Account") && balance<1000) || (accType.equalsIgnoreCase("Current Account") && balance<1000) ){
			try{   
				throw new NumberFormatException();
			}
			catch(NumberFormatException nw)
			{
				System.out.println("Balance is low");
			}
		}   
		return balance;
	}

	void display() throws Exception
	{
		System.out.println("Balance is "+getBalance());   
	}

	public static void main(String[] args) throws Exception {

		Scanner sc= new Scanner(System.in);

		System.out.println("Enter the Customer Name: ");
		String name= sc.nextLine();
		System.out.println("Enter the Account Number: ");
		long accno= sc.nextLong();
		sc.nextLine();
		System.out.println("Enter the Account Type: ");
		String acctype= sc.nextLine();
		System.out.println("Enter the balance amount in the account: ");
		float bal= sc.nextFloat();
		sc.nextLine();

		BankAccount b= new BankAccount(accno, bal, name, acctype);

		System.out.println("Choose the operation to be performed");
		System.out.println("1. Deposit 2. Withdraw 3. View balance 4. Exit");

		while(true){
			int opt= sc.nextInt();
			if(opt==1){
				System.out.println("Enter the amount to be deposited: ");
				float amt= sc.nextFloat();
				sc.nextLine();
				b.deposit(amt);
			}

			else if(opt==2){
				System.out.println("Enter the amount to be withdrawn: ");
				float amt= sc.nextFloat();
				sc.nextLine();
				b.withdraw(amt);
			}

			else if(opt==3){
				float balamt= b.getBalance();
				System.out.println("Balance is "+balamt);
			}

			else if(opt==4){
				sc.close();
				System.exit(0);
			}

			else{
				System.out.println("Invalid option!!");
			}
			
		}

	}
	
}