import java.util.Scanner;

public class BookDetails {
        public static void main(String[] args) throws Exception {
        
        try {
            Scanner sc= new Scanner(System.in);
            System.out.print("Enter the number of books to be added: ");
            int n= sc.nextInt();
            sc.nextLine();
            Book b[]= new Book[n];
            createBooks(n,b,sc);
            showBooks(n,b);
            sc.close();
        }

        catch(Exception e){
            System.out.println("Error occurred!!");
            e.printStackTrace();
        }
    }

    public static void createBooks(int n, Book[] b, Scanner sc){

        for(int i=0; i<n; i++){
            System.out.println("Enter the tile of book "+(i+1)+": ");
            String t= sc.nextLine();
            System.out.println("Enter the price of book "+(i+1)+": ");
            float p= sc.nextFloat();
            sc.nextLine();
            b[i]= new Book();
            b[i].setTitle(t);
            b[i].setPrice(p);
        }
        return;
    }

    public static void showBooks(int n, Book[] b){

        System.out.println("\nBook Title\t\tPrice");
        for(int i=0; i<n; i++){            
            System.out.println(b[i].getTitle()+"\t\tRs. "+b[i].getPrice());
        }
        return;     
    }
}
