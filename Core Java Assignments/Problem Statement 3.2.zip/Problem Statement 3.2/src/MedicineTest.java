public class MedicineTest {
	public static void main(String[] args) 
	{
		MedicineInfo m[] = new MedicineInfo[10];
		int max=3, min= 1;
		for(int i=0;i<10;i++){
			int j= (int) Math.floor(Math.random()*(max-min+1)+min);
			switch(j)
			{
				case 1:
					m[1] = new Tablet();
					m[1].displayLabel();
					break;
				case 2:
					m[2] = new Syrup();
					m[2].displayLabel();
					break;
				case 3:
					m[3] = new Ointment();
					m[3].displayLabel();
					break;
				default: 
					System.out.println("Invalid Choice");
					break;
			}
		}
	}
}