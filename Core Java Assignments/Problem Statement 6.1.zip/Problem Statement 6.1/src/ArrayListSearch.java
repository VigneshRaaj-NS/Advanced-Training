import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Scanner;

public class ArrayListSearch {
	public static void main (String[] args) {
		ArrayList<String> a1 =new ArrayList<String>();
		int n;
		Scanner sc= new Scanner(System.in);
		System.out.print("Enter the number of students:");
		n=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the student names: ");
		for(int i=0;i<n;i++)
		{
			a1.add(sc.nextLine());
		}
		System.out.print("Enter the name of the student to be searched: ");
        String stu= sc.nextLine();

        ListIterator<String> itr= a1.listIterator();
        int pos=0, flag=0; 
        while(itr.hasNext()){
            pos= pos+1;
            if(itr.next().equalsIgnoreCase(stu)){
                flag= 1;
                break;
            }
        }

        if(flag==1){
            System.out.println("The given student name "+stu+" is present at position "+(pos)+" in the list.");
        }

        else{
            System.out.println("The given student name "+stu+" is not present in the list.");
        }		
		sc.close();
	}
}