import java.util.Scanner;

public class NumberSequence {
	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		int a=sc.nextInt();
		sc.nextLine();
		int b= sc.nextInt();
		sc.nextLine();
		int c;
		c=a+b;
		for (int i = 1; i <= 13; i++) {
			if(i==1) {
                System.out.print(a + "\t");
            }
			else if(i==2) {
				System.out.print(b + "\t");
            }
			if(i>=3){				
				System.out.print(c+"\t");
				a=b;
				b=c;
				c=a+b;
			}
		}
		sc.close();
	}

}