import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;

public class EmployeeTest {
	public static void main(String[] args){
	Employee e1=new Employee (101,"Manish Kumar", "No: 3, Raja street, Anna colony, Perambur, Chennai-81");
	Employee e2=new Employee (102,"Ankit Kumar", "No: 6/7, Kannan street, Periyar colony, Thirumangal, Chennai- 28");

	LinkedList<Employee> list = new LinkedList <>();
	list.add(e1);
	list.add(e2);

	addInput(list);
	display(list);	
	}

	public static void addInput(LinkedList<Employee> list) {

		Scanner sc= new Scanner(System.in);
		System.out.print("Enter the number of employees to be added: ");
		int n= sc.nextInt();
		sc.nextLine();        
		Employee e[]= new Employee[n];

		for(int i=0; i<n; i++){
            e[i]= new Employee();
			System.out.print("Enter Employee details: \nName: ");
			e[i].setEname(sc.nextLine());
			System.out.print("Address: ");
			e[i].setAddres(sc.nextLine());
			System.out.print("Emp ID: ");
			e[i].setEmpid(sc.nextInt());
			sc.nextLine();
			System.out.println();
			list.add(e[i]);
		}
		sc.close();
    }

	public static void display(LinkedList<Employee> listPara) {
		ListIterator<Employee> itr = listPara.listIterator();
		System.out.println("Forward Direction Iteration:");
		while (itr.hasNext()) {
		    Employee e=itr.next();
		    System.out.print(e.getEmpid() +"\t");
		    System.out.print(e.getEname() +"\t\t");
		    System.out.print(e.getAddress());
		    System.out.println();
		        
		}		
	}
}
