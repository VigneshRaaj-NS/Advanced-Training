import java.util.Scanner;

public class EvenNumber {
    public static void main(String[] args) throws Exception {
        System.out.println("***This program displays the even numbers less than or equal to the given number***");
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a valid positive integer: ");
        int i= 2, n= sc.nextInt();

        if(n<2){
            System.out.println("The given number "+n+" does not have even numbers lesser than it");
        }

        while(true){
            if(i%2==0 && i<=n){
                System.out.println(i);
                i=i+2;
            }
            else
                break;
        }
    }
}
