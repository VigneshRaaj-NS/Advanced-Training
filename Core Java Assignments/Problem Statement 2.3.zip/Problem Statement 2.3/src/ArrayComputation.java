public class ArrayComputation {
	public static void main(String[] args) {        
        int arr[];
        arr= new int[] {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
        System.out.println("Length of array: "+arr.length);
        int sum = 0; 
        int i=0;
        for(i = 0; i <= 14; i++) {  
            sum = sum + arr[i]; 
        }
        arr[15]=sum;
        System.out.println( "Sum upto 14th index is stored at 15th index and value: "+sum);
        System.out.println("New array values after adding sum value at 15th index: ");
        for (int j : arr) {
            System.out.print(j+"\t");
        }
        System.out.println();

        int avg=sum/15;
        System.out.println("Average of all elements in the array: "+avg);
        arr[16]=avg;
        System.out.println("Average is stored at 16th index. New array values after adding the average at 16th index: ");
        for (int j = 0; j < arr.length; j++) {  
            System.out.print(arr[j]+"\t");  
        }
        System.out.println();

        int temp= arr[0];
        for(int j = 0; j<14; j++ ){
            if(arr[j+1]<arr[j] && arr[j+1]<temp){
                temp= arr[j+1];
            }
        }        
        System.out.println("The smallest element in an array is: "+temp);
        arr[17]= temp;
        System.out.println("Smallest value is stored at 17th index.");
        System.out.println("New array values after adding the smallest value at 17th index: ");
        for(int k: arr){
            System.out.print(k+"\t");
        }
    }
}