import java.util.Scanner;

public class TestRectangle {
    public static void main(String[] args) {
        System.out.println("Enter length and width of 5 rectangles\n");
        Scanner sc= new Scanner(System.in);
        float l, w; int i=0;
        Rectangle r[]= new Rectangle[5];

        while(i<5){
            System.out.println("Enter length of Rectangle"+(i+1)+": ");
            l= sc.nextFloat();
            System.out.println("Enter width of Rectangle"+(i+1)+": ");
            w=sc.nextFloat();
            r[i] =new Rectangle(l,w);
            i++;
        }

        while(true){
            System.out.print("Choose the required option:\n1. To display properties of all rectangles\n");
            System.out.print("2. To display properties of particular rectangle object\n");
            System.out.print("3. To change properties of a particular rectangle object\n4. Exit application\n");
            int opt= sc.nextInt();

            if(opt==1){
                for(i=0; i<5; i++){
                    System.out.println("Rectangle "+(i+1)+": ");
                    System.out.println("Length: "+r[i].getLength());
                    System.out.println("Width: "+r[i].getWidth());
                    System.out.println("Area: "+r[i].calculateArea()+"\n");
                }
                continue;
            }

            else if(opt==2){
                System.out.print("Enter the rectangle object number: ");
                int o= sc.nextInt();
                System.out.println("Length: "+r[o-1].getLength());
                System.out.println("Width: "+r[o-1].getWidth());
                System.out.println("Area: "+r[o-1].calculateArea()+"\n");
                continue;
            }

            else if(opt==3){
                System.out.print("Enter the rectangle object number: ");
                int o= sc.nextInt();

                while(true){
                    System.out.println("1. To change length\t 2. To change width\t 3. To change both length and width");
                    int o1= sc.nextInt();
                    if(o1==1){
                        System.out.print("Enter value: ");
                        r[o-1].setLength(sc.nextFloat());
                        break;
                    }

                    else if(o1==2){
                        System.out.print("Enter value: ");
                        r[o-1].setWidth(sc.nextFloat());
                        break;
                    }

                    else if(o1==3){
                        System.out.print("Enter length value: ");
                        r[o-1].setLength(sc.nextFloat());
                        System.out.print("Enter width value: ");
                        r[o-1].setWidth(sc.nextFloat());
                        break;
                    }

                    else{
                        System.out.println("Enter valid option!!");
                        continue;
                    }
                }
                continue;
            }

            else if(opt==4){
                System.out.println("Application closed successfully!!");
                sc.close();
                System.exit(0);
            }

            else{
                System.out.println("Enter a valid option!!");
                continue;
            }

        }

    }
    
}