public class Storage{

	int x;
	public Storage()  {
		super();
	}

	public Storage(int x) {
		super();
		this.x = x;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}	
	
}
