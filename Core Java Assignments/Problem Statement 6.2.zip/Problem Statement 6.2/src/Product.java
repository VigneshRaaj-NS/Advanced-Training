import java.util.Hashtable;
import java.util.Scanner;

public class Product {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Hashtable<String,String> hm=new Hashtable<String,String>();
		System.out.println("Enter the Product Id and Name:");
		for(int i=0;i<10;i++)
		{
			hm.put(sc.nextLine(), sc.nextLine());
		}
		System.out.println("The Product List:");
		System.out.println(hm);
		System.out.println("Enter the Product Id to be removed:");
		String id = sc.nextLine();
		hm.remove(id);
		System.out.println("Item removed");
		System.out.println("The Product List is:");
		System.out.println(hm.toString());
		System.out.println("Enter the Product Id of the product to be searched:");
		String sid=sc.nextLine();
		if(hm.containsKey(sid))
		{
			System.out.println(hm.get(sid));
		}
		else {
			System.out.println("The given Product Id does not exist");
		}
		sc.close();
	}
}