import java.util.HashMap;
import java.util.Scanner;

public class Frequency {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        System.out.print("Enter length of array: ");
        int n=sc.nextInt();
		sc.nextLine();
        int[] arr=new int[n];
        for (int i = 0; i < arr.length; i++) {
			arr[i]= sc.nextInt();
		}

        HashMap<Integer,Integer> freqMap= new HashMap<>();
        freqMap=arrayDataTransferToMap(arr);
           
        for(int value : freqMap.keySet())//printing op
        {
            System.out.println(value + " occurs " + freqMap.get(value)+ " times");
        }
		
		sc.close();
    }

	
	public static HashMap<Integer,Integer> arrayDataTransferToMap(int[] arr){
		HashMap<Integer,Integer> freqMap= new HashMap<>();
		for (int val : arr) {
			if(!freqMap.containsKey(val)) {
				freqMap.put(val,1);
			}
			else {//If the key is duplicate then the old key is replaced with the new value
				freqMap.put(val,freqMap.get(val)+1);
			}
		}
		return freqMap;
    }

}